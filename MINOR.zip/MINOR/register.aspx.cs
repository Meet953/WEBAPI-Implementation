﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class register : System.Web.UI.Page
{
    WSVendor wsusr = new WSVendor();
    Boolean exists = false;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        using (SqlCommand cmd = new SqlCommand("SELECT Count([UserName]) As Usercount FROM [dbo].[AllUser]  WHERE [UserName] = '" + UserName.Text + "' ", con))
        {
            exists = (int)cmd.ExecuteScalar() > 0;
        }
       
        if (exists)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('UserName already taken. Choose another one')", true);
        }
        else
        {
            AllUser usr = new AllUser();
            usr.UsrName = UserName.Text;
            usr.UsrPassword = Password.Text;
            usr.UsrPhone = txtPhone.Text;
            usr.UsrEmail = Email.Text;

            wsusr.AddUsers(usr);
         
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('User Added Successfully')", true);

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
}