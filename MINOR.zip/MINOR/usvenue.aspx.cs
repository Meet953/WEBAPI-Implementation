﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using globalvariables;

public partial class usvenue : System.Web.UI.Page
{
    private static int venueID = 0;
    Boolean exists = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie reqCookies = Request.Cookies["userInfo"];
        string User_name = string.Empty;

        if (reqCookies != null)
        {
            User_name = reqCookies["UsrNam"].ToString();
        }

        lbbl.Text = User_name;
    }

    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        con.Close();
        return dt;
    }


    protected void rbHotel_CheckedChanged(object sender, EventArgs e)
    {
        String str = "Hotel";
        SqlCommand cmd = new SqlCommand("Select [VenueId],[VenuePicPath],[VenueName],[VenueAddress],[VenuePrice] from [dbo].[DetVen] WHERE [VenueCat] = '" + str + "'");
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();
    }

    protected void rbHall_CheckedChanged(object sender, EventArgs e)
    {
        String str = "Hall";
        SqlCommand cmd = new SqlCommand("Select [VenueId],[VenuePicPath],[VenueName],[VenueAddress],[VenuePrice] from [dbo].[DetVen] WHERE [VenueCat] = '" + str + "'");
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();
    }

    protected void rbRestro_CheckedChanged(object sender, EventArgs e)
    {
        String str = "Restaraunt";
        SqlCommand cmd = new SqlCommand("Select [VenueId],[VenuePicPath],[VenueName],[VenueAddress],[VenuePrice] from [dbo].[DetVen] WHERE [VenueCat] = '" + str + "'");
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();
    }

    protected void rbBar_CheckedChanged(object sender, EventArgs e)
    {
        String str = "Bar";
        SqlCommand cmd = new SqlCommand("Select [VenueId],[VenuePicPath],[VenueName],[VenueAddress],[VenuePrice] from [dbo].[DetVen] WHERE [VenueCat] = '" + str + "'");
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();
    }

    protected void rbFarm_CheckedChanged(object sender, EventArgs e)
    {
        String str = "Farm House";
        SqlCommand cmd = new SqlCommand("Select [VenueId],[VenuePicPath],[VenueName],[VenueAddress],[VenuePrice] from [dbo].[DetVen] WHERE [VenueCat] = '" + str + "'");
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();
    }

    protected void updateVendor()
    {
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        string trpic = "gv/true.png"; 
        SqlCommand cmd = new SqlCommand("Update [dbo].[DetVen] set [VenueStatus] = @pipa where [VenueId] = @ID", con);
        cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = usvenue.venueID;
        cmd.Parameters.Add("@pipa", SqlDbType.VarChar).Value = trpic;
        cmd.ExecuteNonQuery();
        con.Close();
    }

    protected void btnAddVen_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();

        int id = Convert.ToInt16(Session["usrid"]);
        string evName = Globals.gbEventName;
        string date = txtDate.Text;
        string data = txtInfo.Text;

        using (SqlCommand cmd = new SqlCommand("SELECT Count([UserEvent]) As Usercount FROM [dbo].[DetUser] WHERE [UserEvent] = '" + evName + "' AND [UserID] = '" + id + "' ", con))
        {
            exists = (int)cmd.ExecuteScalar() > 0;
        }

        if(exists)
        {
            if (date != null)
            {
                SqlCommand cmd2 = new SqlCommand("SELECT [Id] FROM [dbo].[DetUser] WHERE [UserEvent] = '" + evName + "' AND [UserID] = '" + id + "' ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int pkey = Convert.ToInt16(ds.Tables[0].Rows[0][0]);

                SqlCommand cmd = new SqlCommand("Update [dbo].[DetUser] set [UserVenueID] = @venid, [UserVenueDate] = @vendate, [UserVenueNote] = @info  where [Id] = @ID", con);
                cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = pkey;
                cmd.Parameters.Add("@venid", SqlDbType.VarChar).Value = usvenue.venueID;
                cmd.Parameters.Add("@vendate", SqlDbType.VarChar).Value = date;
                cmd.Parameters.Add("@info", SqlDbType.VarChar).Value = data;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You forgot to select Date')", true);
            }
        }

        else
        {
   
        if (date != null)
        {
            
            SqlCommand cmd = new SqlCommand("Insert into [dbo].[DetUser] ([UserID],[UserEvent],[UserVenueID],[UserVenueDate],[UserVenueNote]) Values(@id, @event, @venid, @vendate,@info)", con);

            cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = id;
            cmd.Parameters.Add("@event", SqlDbType.VarChar).Value = evName;
            cmd.Parameters.Add("@venid", SqlDbType.VarChar).Value = usvenue.venueID;
            cmd.Parameters.Add("@vendate", SqlDbType.VarChar).Value = date;
            cmd.Parameters.Add("@info", SqlDbType.VarChar).Value = data;
            cmd.ExecuteNonQuery();
            con.Close();

        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You forgot to select Date')", true);
        }


        }

        updateVendor();
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You have Succesfully Booked Venue')", true);


    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        String str = GridView1.SelectedRow.Cells[0].Text;
        usvenue.venueID = Convert.ToInt16(str);
        btnAdd.Visible = true;
       
    }

    protected void demo_Click(object sender, EventArgs e)
    {
        if (usvenue.venueID == 0)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You have not chosen any Venue')", true);
        }
        else
        {
            lblVenueID.Text = usvenue.venueID.ToString();
            UpdatePanel2.Update();
            ModalPopupExtender1.Show();
        }
    }
}