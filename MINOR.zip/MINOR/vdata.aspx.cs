﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.IO;


public partial class vdata : System.Web.UI.Page
{
    static AllVendor resVendor;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!IsPostBack)
            BindData();
    }

    static async Task<AllVendor> GetingVendorAsync(int Venid)
    {
        //  int id = 0;
        using (var client = new HttpClient())
        {

            client.BaseAddress = new Uri("http://localhost:56909/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");

            HttpResponseMessage response = await client.GetAsync("api/Vendor/VendorInfo/" + Venid);
            response.EnsureSuccessStatusCode();
            if (response.IsSuccessStatusCode)
            {
                string str = await response.Content.ReadAsStringAsync();
                vdata.resVendor = JsonConvert.DeserializeObject<AllVendor>(str);
                System.Diagnostics.Debug.WriteLine("Con");
                System.Diagnostics.Debug.WriteLine("result " + str);
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Connection Error");
            }
            return vdata.resVendor;
        }

    }


    static async Task gett(int id)
    {
        var task = await GetingVendorAsync(id);
        // id = Convert.ToInt32(task);
        // System.Diagnostics.Debug.WriteLine("22id" + id);
    }

    public void BindData()
    {

        int id = Int32.Parse(Session["venid"].ToString());
        Task.Run(() => gett(id)).Wait();

        Pic.ImageUrl = vdata.resVendor.VenPicPath;
        UserName.Text = vdata.resVendor.VenName;
        ComName.Text = vdata.resVendor.VenCompany;
        Phone.Text = vdata.resVendor.VenPhone;
        Email.Text = vdata.resVendor.VenEmail;
        Info.Text = vdata.resVendor.VenDetails;

        /*   SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
           con.Open();
           SqlCommand cmd = new SqlCommand("SELECT [VenUserName],[VenCompany],[VenPhone],[VenEmail],[VenDetails],[VenPicPath] FROM [dbo].[AllVd] WHERE [VenId] ='" + Session["venid"] + "' ", con);
           SqlDataAdapter da = new SqlDataAdapter(cmd);
           DataSet ds = new DataSet();
           da.Fill(ds);

           String usrname = ds.Tables[0].Rows[0][0].ToString();
           String cmpname = ds.Tables[0].Rows[0][1].ToString();
           String phone = ds.Tables[0].Rows[0][2].ToString();
           String email = ds.Tables[0].Rows[0][3].ToString();
           String details = ds.Tables[0].Rows[0][4].ToString();
           String picpath = ds.Tables[0].Rows[0][5].ToString();

           Pic.ImageUrl = picpath;
           UserName.Text = usrname;
           ComName.Text = cmpname;
           Phone.Text = phone;
           Email.Text = email;
           Info.Text = details;  */

    }
}