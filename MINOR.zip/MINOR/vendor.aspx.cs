﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

public partial class vendor : System.Web.UI.Page
{
    Boolean exists = false;
    static int id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    static async Task<int> ValidateVendorAsync(string uname, string pass)
    {
      //  int id = 0;
        using (var client = new HttpClient())
        {
           
            client.BaseAddress = new Uri("http://localhost:56909/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
           
            HttpResponseMessage response = await client.GetAsync("api/Vendor/" + uname + "/" + pass);
            response.EnsureSuccessStatusCode();
            if (response.IsSuccessStatusCode)
            {
               string my = await response.Content.ReadAsStringAsync();
                vendor.id = Convert.ToInt32(my);
                System.Diagnostics.Debug.WriteLine("Con");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Connection Error");
            }

            System.Diagnostics.Debug.WriteLine("id"+id);
            return id;
        }
            
    }

    static async Task Validate(string uname,string pass)
    {
        var task = await ValidateVendorAsync(uname, pass);
       // id = Convert.ToInt32(task);
       // System.Diagnostics.Debug.WriteLine("22id" + id);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
      
        String uname = UserName.Text;
        String pass = Password.Text;
        Task.Run(() => Validate(uname, pass)).Wait();
        
        System.Diagnostics.Debug.WriteLine("33id" + vendor.id);

        if (vendor.id > 0)
        {
            Session["venid"] = vendor.id;
            HttpCookie ckVen = new HttpCookie("VnInfo");
            ckVen["UsrNam"] = UserName.Text;
            ckVen["Pass"] = Password.Text;
            Response.Cookies.Add(ckVen);

            Response.Redirect("vdata.aspx");

        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You are not Registered')", true);
        }


        /*   SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
           con.Open();
           using (SqlCommand cmd = new SqlCommand("SELECT Count([VenUserName]) As Usercount FROM [dbo].[AllVd] WHERE [VenUserName] = '" + UserName.Text + "' AND [VenPassword] = '" + Password.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS ", con))
           {
               exists = (int)cmd.ExecuteScalar() > 0;
           }

           if (exists)
           {
               SqlCommand cmd = new SqlCommand("SELECT [VenId] FROM [dbo].[AllVd] WHERE [VenUserName] = '" + UserName.Text + "' AND [VenPassword] = '" + Password.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS ", con);
               SqlDataAdapter da = new SqlDataAdapter(cmd);
               DataSet ds = new DataSet();
               da.Fill(ds);
               int id = Convert.ToInt16(ds.Tables[0].Rows[0][0]);
               Session["venid"] = id;

               HttpCookie ckVen = new HttpCookie("VnInfo");
               ckVen["UsrNam"] = UserName.Text;
               ckVen["Pass"] = Password.Text;
               Response.Cookies.Add(ckVen);

               Response.Redirect("vdata.aspx");
           }
           else
           {
               ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You are not Registered')", true);
           }
           */
    }
}