﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

public partial class venreg : System.Web.UI.Page
{

    WSVendor wsven = new WSVendor();
    Boolean exists = false;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRegister_Click1(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        using (SqlCommand cmd = new SqlCommand("SELECT Count([VenUserName]) As Usercount FROM [dbo].[AllVd] WHERE [VenUserName] = '" + txtUserName.Text + "' ", con))
        {
            exists = (int)cmd.ExecuteScalar() > 0;
        }
        if (exists)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('UserName already taken. Choose another one')", true);
        }
        else
        {
            AllVendor ven = new AllVendor();
            ven.VenName = txtUserName.Text;
            ven.VenCompany = txtCompany.Text;
            ven.VenDetails = txtAbout.Text;
            ven.VenPhone = txtPhone.Text;
            ven.VenEmail = txtEmail.Text;
            ven.VenPassword = txtPassword.Text;
            string FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
            FileUpload1.SaveAs(Server.MapPath("picsven1/" + FileName));
            ven.VenPicName = FileName;
            ven.VenPicPath = "picsven1/" + FileName;

            var url = AddVendorAsync(ven);

            //     wsven.AddVendors(ven);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Vendor Added Successfully from'+url)", true);
            
        }
    }


    static async Task<Uri> AddVendorAsync(AllVendor Ven)
    { 
        using (var client = new HttpClient())
        {
            client.BaseAddress = new Uri("http://localhost:56909/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");

            StringContent content = new StringContent(JsonConvert.SerializeObject(Ven), Encoding.UTF8, "application/json");
        
            HttpResponseMessage response = await client.PostAsync("api/Vendor", content);
           
            response.EnsureSuccessStatusCode();


            if (response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine("Success " + response);
            }

            // return URI of the created resource.
            return response.Headers.Location;

          
        }
    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("vendor.aspx");
    }
}