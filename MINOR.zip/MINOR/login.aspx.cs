﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    Boolean exists = false;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        using (SqlCommand cmd = new SqlCommand("SELECT Count([UserName]) As Usercount FROM [dbo].[AllUser] WHERE [UserName] = '" + UserName.Text + "' AND [Password] = '" + Password.Text + "' ", con))
        {
            exists = (int)cmd.ExecuteScalar() > 0;
        }

        if (exists)
        {
            SqlCommand cmd = new SqlCommand("SELECT [Id] FROM [dbo].[AllUser] WHERE [UserName] = '" + UserName.Text + "' AND [Password] = '" + Password.Text + "' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            int id = Convert.ToInt16(ds.Tables[0].Rows[0][0]);
            Session["usrid"] = id;

            HttpCookie ckUsr = new HttpCookie("userInfo");
            ckUsr["UsrNam"] = UserName.Text;
            ckUsr["Pass"] = Password.Text;
            Response.Cookies.Add(ckUsr);

            Response.Redirect("usdata.aspx");
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You are not Registered')", true);
        }
    }
}