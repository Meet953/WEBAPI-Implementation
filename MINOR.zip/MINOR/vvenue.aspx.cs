﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.IO.Compression;
using System.IO;
using System.Configuration;

public partial class vendor_vvenue : System.Web.UI.Page
{

    private int flag = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData();
        }
    }

    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);

        if(dt.Rows.Count > 0 )
        {
            con.Close();
            return dt;
        }
         else
        {
            flag = 1;
            DataTable dtEmpty = new DataTable();
            //Here ensure that you have added all the column available in your gridview
            dtEmpty.Columns.Add("VenueID", typeof(int));
            dtEmpty.Columns.Add("VenuePicPath", typeof(string));
            dtEmpty.Columns.Add("VenueName", typeof(string));
            dtEmpty.Columns.Add("VenueCat", typeof(string));
            dtEmpty.Columns.Add("VenueAddress", typeof(string));
            dtEmpty.Columns.Add("VenuePrice", typeof(decimal));
            dtEmpty.Columns.Add("VenueStatus", typeof(string));

            DataRow datatRow = dtEmpty.NewRow();

            //Inserting a new row,datatable .newrow creates a blank row
            dtEmpty.Rows.Add(datatRow);//adding row to the datatable
            
            return dtEmpty;
        }
    }

    private void BindData()
    {
        SqlCommand cmd = new SqlCommand("Select [VenueId],[VenuePicPath],[VenueName],[VenueCat],[VenueAddress],[VenuePrice],[VenueStatus] from [dbo].[DetVen] WHERE [VenId] = '" + Convert.ToInt16(Session["venid"]) + "'");
        GridView1.DataSource = GetData(cmd);

        if (flag == 1)
        { 
            GridView1.DataBind();
            GridView1.Rows[0].Visible = false;
        }

        else
        {
            GridView1.DataBind();
        }
      
    }

    protected void AddVendorDetails(object sender, EventArgs e)
    {
        FileUpload fileupload = ((FileUpload)GridView1.FooterRow.FindControl("FileUpload1"));

        if (fileupload.HasFile)
        {
            string file = System.IO.Path.Combine(Server.MapPath("~/picsven2/"), fileupload.FileName);
            fileupload.SaveAs(file);
        }

        //string filename = fileupload.FileName;
        //fileupload.SaveAs(Server.MapPath("~/picsven2/" + filename));
        //string PicPath = "picsven2/" + filename;
        
        string name = ((TextBox)GridView1.FooterRow.FindControl("txtVenueName")).Text;
        string category = ((DropDownList)GridView1.FooterRow.FindControl("ddlVenueCat")).SelectedItem.Value.ToString();
        string address = ((TextBox)GridView1.FooterRow.FindControl("txtVenueAdd")).Text;
        string stprice = ((TextBox)GridView1.FooterRow.FindControl("txtVenuePrice")).Text;
        decimal price = Convert.ToDecimal(stprice);
         
        int venid = Convert.ToInt16(Session["venid"]);

        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        SqlCommand cmd = new SqlCommand("Insert into[dbo].[DetVen]([VenId],[VenueName],[VenueCat],[VenueAddress],[VenuePicPath],[VenuePrice]) Values(@ID, @Name, @Cat, @Add, @PicPath, @Price)",con);
        
        cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = venid;
        cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = name;
        cmd.Parameters.Add("@Cat", SqlDbType.VarChar).Value = category;
        cmd.Parameters.Add("@Add", SqlDbType.VarChar).Value = address;
        cmd.Parameters.Add("@PicPath", SqlDbType.VarChar).Value = fileupload.FileName;
        cmd.Parameters.Add("@Price", SqlDbType.VarChar).Value = price;
        cmd.ExecuteNonQuery();
        con.Close();

        BindData();
    }

    protected void EditVendorDetails(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BindData();
    }
    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        BindData();
    }

    protected void UpdateVendorDetails(object sender, GridViewUpdateEventArgs e)
    {
        string idstr = ((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text;
        int VenID = Convert.ToInt16(idstr);

        FileUpload FileUpload1 = (FileUpload)GridView1.Rows[e.RowIndex].FindControl("FileUpload1");
        string path;

        if (FileUpload1.HasFile)
        {
            string file = System.IO.Path.Combine(Server.MapPath("~/picsven2/"), FileUpload1.FileName);
            FileUpload1.SaveAs(file);
            path = FileUpload1.FileName;
        }
        else
        {
            // use previous user image if new image is not changed    
            Image img = (Image)GridView1.Rows[e.RowIndex].FindControl("imgPic");
            path = img.ImageUrl;
        }

        string name = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtVenueName")).Text;
        string category = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("ddlVenueCat")).SelectedItem.Value.ToString();
        string address = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtVenueAdd")).Text;
        string stprice = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtVenuePrice")).Text;
        decimal price = Convert.ToDecimal(stprice);

        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        SqlCommand cmd = new SqlCommand("Update[dbo].[DetVen] set[VenueName] = @name, [VenueCat] = @cat, [VenueAddress] = @add, [VenuePrice] = @price, [VenuePicPath] = @picpath where [VenueId] = @ID",con);
        cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = VenID;
        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
        cmd.Parameters.Add("@cat", SqlDbType.VarChar).Value = category;
        cmd.Parameters.Add("@add", SqlDbType.VarChar).Value = address;
        cmd.Parameters.Add("@price", SqlDbType.VarChar).Value = price;
        cmd.Parameters.Add("@picpath", SqlDbType.VarChar).Value = path;
        cmd.ExecuteNonQuery();
        con.Close();

        GridView1.EditIndex = -1;

        BindData();
    }

    protected void DeleteVendorDetails(object sender, EventArgs e)
    {
        LinkButton lnkRemove = (LinkButton)sender;
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        con.Open();
        SqlCommand cmd = new SqlCommand("Delete from [dbo].[DetVen] where [VenueId]=@ID",con);
        cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = lnkRemove.CommandArgument;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        BindData();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string idstr = (GridView1.SelectedRow.FindControl("lblID") as Label).Text;
        int VenueID = Convert.ToInt16(idstr);
        string status = (GridView1.SelectedRow.FindControl("lblStatus") as Label).Text;

        if(status.Equals("gv/false.png"))
        {
            UpdatePanel3.Update();
            ModalPopupExtender2.Show();
        }

        else if (status.Equals("gv/true.png"))
        {
            SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT [UserVenueDate] ,[UserVenueNote] FROM [dbo].[DetUser] WHERE [UserVenueID] = '" + VenueID  + "' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            string date = (ds.Tables[0].Rows[0][0]).ToString();
            string note = (ds.Tables[0].Rows[0][1]).ToString();

            lblVenueID.Text = VenueID.ToString();
            lblVenueDate.Text = date;
            lblInfo.Text = note;

            UpdatePanel2.Update();
            ModalPopupExtender1.Show();
        }
    }
}