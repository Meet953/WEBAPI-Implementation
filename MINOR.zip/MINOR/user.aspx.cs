﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using globalvariables;

public partial class user : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie reqCookies = Request.Cookies["userInfo"];
        string User_name = string.Empty;

        if (reqCookies != null)
        {
            User_name = reqCookies["UsrNam"].ToString();
        }

        lbbl.Text = User_name;
        lblU.Text = "Welcome" + User_name;
        lbEv.Text = "Your Event Code : " + Globals.gbEventName;
    }
    
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}