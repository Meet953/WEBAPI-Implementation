﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using globalvariables;

public partial class usdata : System.Web.UI.Page
{
    Boolean exists = false;

    protected void Page_Load(object sender, EventArgs e)
    {

        HttpCookie reqCookies = Request.Cookies["userInfo"];
        string User_name = string.Empty;

        if (reqCookies != null)
        {
            User_name = reqCookies["UsrNam"].ToString();
        }

        lbbl.Text = User_name;
    }

    protected void btnEvent_Click(object sender, EventArgs e)
    {
        string evnm = txtEvName.Text;
        Globals.SetgbEventName(evnm);
        Response.Redirect("user.aspx");
        
    }
}