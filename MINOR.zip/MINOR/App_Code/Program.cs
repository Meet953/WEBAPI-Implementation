﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;

/// <summary>
/// Summary description for Program
/// </summary>
public class Program
{
    static HttpClient client = new HttpClient();
    static void Main(string[] args)
    {
        client.BaseAddress = new Uri("http://localhost:56908");
       // PutTrial();
    
    }
  /*  private static void PutTrial()
    {
        Person person = new Person() { FirstName = "Iron", LastName = "Man", Age = 30 };
        Console.WriteLine("Before calling the PUT method");
        Console.WriteLine("-----------------------------");
        Console.WriteLine("FirstName of the Person is : {0}", person.FirstName);
        Console.WriteLine("LastName of the Person is  : {0}", person.LastName);
        Console.WriteLine("Fullname of the Person is  : {0}", person.FullName);
        Console.WriteLine("Age of the Person is       : {0}", person.Age);
        Console.WriteLine();
        string serilized = JsonConvert.SerializeObject(person);
        var inputMessage = new HttpRequestMessage
        {
            Content = new StringContent(serilized, Encoding.UTF8, "application/json")
        };
        inputMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        HttpResponseMessage message = client.PutAsync("api/trial", inputMessage.Content).Result;
        if (message.IsSuccessStatusCode)
        {
            var inter = message.Content.ReadAsStringAsync();
            Person reslutPerson = JsonConvert.DeserializeObject<Person>(inter.Result);
            Console.WriteLine("Person returned from PUT method:");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("FirstName of the Person is : {0}", reslutPerson.FirstName);
            Console.WriteLine("LastName of the Person is  : {0}", reslutPerson.LastName);
            Console.WriteLine("Fullname of the Person is  : {0}", reslutPerson.FullName);
            Console.WriteLine("Age of the Person is       : {0}", reslutPerson.Age);
        }
    }*/
}
//}