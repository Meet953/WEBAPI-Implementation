﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AllVendor
/// </summary>
public class AllVendor
{
    public string VenName { get; set; }
    public string VenCompany { get; set; }
    public string VenPassword { get; set; }
    public string VenPhone { get; set; }
    public string VenEmail { get; set; }
    public string VenDetails { get; set; }
    public string VenPicName { get; set; }
    public string VenPicPath { get; set; }

}

public class AllUser
{
    public string UsrName { get; set; }
    public string UsrEmail { get; set; }
    public string UsrPhone { get; set; }
    public string UsrPassword { get; set; }
}
