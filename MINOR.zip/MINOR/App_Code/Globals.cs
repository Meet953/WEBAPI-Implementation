﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Globals
/// </summary>
namespace globalvariables
{ 
public static class Globals
{
    public static string gbEventName { get; set; }

    public static void SetgbEventName(string newEv)
    {
        gbEventName = newEv;
    }
}
}