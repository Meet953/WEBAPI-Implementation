﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for WSVendor
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WSVendor : System.Web.Services.WebService
{

    public WSVendor()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public void AddVendors(AllVendor Ven)
    {
       SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        SqlCommand com = new SqlCommand("[dbo].[InsVendor]", con);
        com.CommandType = CommandType.StoredProcedure;

        com.Parameters.AddWithValue("@user", Ven.VenName);
        com.Parameters.AddWithValue("@compnay", Ven.VenCompany);
        com.Parameters.AddWithValue("@passwd", Ven.VenPassword);
        com.Parameters.AddWithValue("@phone", Ven.VenPhone);
        com.Parameters.AddWithValue("@email", Ven.VenEmail);
        com.Parameters.AddWithValue("@details", Ven.VenDetails);
        com.Parameters.AddWithValue("@picname", Ven.VenPicName);
        com.Parameters.AddWithValue("@picpath", Ven.VenPicPath);

        con.Open();
        int i = com.ExecuteNonQuery();
        con.Close();
       
    }

    [WebMethod]
    public void AddUsers(AllUser Usr)
    {
        SqlConnection con = new SqlConnection(" Data Source = DELL; Initial Catalog = EVENT; Integrated Security = True");
        SqlCommand com = new SqlCommand("[dbo].[InsUser]", con);
        com.CommandType = CommandType.StoredProcedure;

        com.Parameters.AddWithValue("@user", Usr.UsrName);
        com.Parameters.AddWithValue("@passwd", Usr.UsrPassword);
        com.Parameters.AddWithValue("@phone", Usr.UsrPhone);
        com.Parameters.AddWithValue("@email", Usr.UsrEmail);

        con.Open();
        int i = com.ExecuteNonQuery();
        con.Close();

    }


}
